
<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

<?php $__env->startSection('title'); ?>
إنشاء قسم جديد
<?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <?php $__env->startSection('PageTitle'); ?>
    إنشاء قسم جديد
    <?php $__env->stopSection(); ?>
        <!-- breadcrumb -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('content'); ?>
        <!-- row -->
        <div class="row">
            <div class="col-md-12 mb-30">
                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <ul class=" alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <form action="<?php echo e(Route('departments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">اسم القسم</label>
                                <input class="form-control" type="text" name="name" id="name"
                                    placeholder="أدخل اسم القسم">
                            </div>

                            <div class="form-group">
                                <label for="title">عنوان القسم</label>
                                <input class="form-control" type="text" name="title" id="title"
                                    placeholder="أدخل عنوان القسم">
                            </div>

                            <div class="form-group">
                                <label for="description">وصف القسم</label>
                                <textarea class=" form-control" type="text" name="description"
                                    placeholder="أدخل وصف القسم" id="summernote" ></textarea>
                            </div>

                    </div>
                    <div class="form-group">
                        <label for="project_id">اختر المشروع</label>
                        <select name="project_id" class="custom-select">
                            <option disabled selected>اختر المشروع</option>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="parent_id">اختر نوع القسم</label>
                        <select name="type" id="" class="custom-select">
                            <option value="1">قسم رئيسي</option>
                            <option value="0">قسم فرعي</option>
                        </select>
                    </div>
                    <div class="form-group" style="display: none">
                        <label for="parent_id">اختر القسم الرئيسي</label>
                        <select name="parent_id" class="custom-select">

                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit">إنشاء</button>
                    </form>
                </div>
            </div>
        </div>
        </div>
        <!-- row closed -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

        <script>
            $(document).ready(function () {
                $('#summernote').summernote({
                    placeholder: 'أدخل وصف القسم',
                    tabsize: 2,
                    height: 200
                });
                $('select[name="type"]').on('change', function () {
                    var depart = $(this).val();
                    if (depart == '0') {
                        $('select[name="parent_id"]').parent().show()
                    } else {
                        $('select[name="parent_id"]').parent().hide()
                    }
                })
            });

        </script>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indexes\resources\views\departments\create.blade.php ENDPATH**/ ?>