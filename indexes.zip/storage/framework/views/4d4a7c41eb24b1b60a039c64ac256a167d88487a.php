
<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
قائمة الأقسام الفرعية
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
قائمة الأقسام الفرعية للقسم الرئيسي <?php echo e($department->name); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">

    <div class="col-xl-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">

                <div class="table-responsive">
                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                        data-page-length="50" style="text-align: center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم القسم</th>
                                <th>العمليات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 0; ?>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $i++; ?>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($department->name); ?></td>
                                    <td class="d-flex justify-content-center">
                                        <a target="_blank" href="<?php echo e(route('show.project',[$department->project_id,$department->parent_id,$department])); ?>"
                                            class="btn btn-info btn-sm mr-3" title="عرض المشروع">عرض المشروع</a>
                                        <a href="<?php echo e(route('departments.edit',$department)); ?>"
                                            class="btn btn-info btn-sm mr-3" title="تعديل المشروع"><i
                                                class="fa fa-edit"></i></a>
                                        <form
                                            action="<?php echo e(route('departments.destroy',$department)); ?>"
                                            method="POST">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                title="حذف المشروع"><i class="fa fa-trash"></i></button>
                                        </form>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indexes\resources\views\branches\index.blade.php ENDPATH**/ ?>