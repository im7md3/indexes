
<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">

    <?php $__env->startSection('title'); ?>
تعديل قسم
    <?php $__env->stopSection(); ?>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('page-header'); ?>
        <!-- breadcrumb -->
        <?php $__env->startSection('PageTitle'); ?>
        تعديل قسم
        <?php $__env->stopSection(); ?>
            <!-- breadcrumb -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('content'); ?>
            <!-- row -->
            <div class="row">
                <div class="col-md-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <ul class=" alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <form action="<?php echo e(Route('departments.update',$department)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">اسم القسم</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        placeholder="أدخل اسم المشروع" value="<?php echo e($department->name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="title">عنوان القسم</label>
                                    <input class="form-control" type="text" name="title" id="title"
                                        placeholder="أدخل عنوان القسم"  value="<?php echo e($department->title); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="description">وصف القسم</label>
                                    <textarea class="form-control" type="text" name="description" 
                                        placeholder="أدخل وصف القسم"   id="summernote" ><?php echo e($department->description); ?></textarea>
                                </div>
                                <div class='file file--uploading'>
                                    <label for='input-file'>
                                        <i style="margin: 5px;" class="fas fa-paperclip"></i> ارفاق ملف
                                    </label><br>
                                    <input id='input-file' type='file' name="depart_file[]" accept="image/jpeg,image/gif,image/png,application/pdf" multiple/>
                                </div>
                                <div class="form-group">
                                    <label for="name">اختر المشروع</label>
                                    <select name="project_id"  class="custom-select">
                                        <option>اختر حالة المشروع</option>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>" <?php echo e($project->id==$department->project_id?'selected':''); ?>><?php echo e($project->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="parent_id">اختر نوع القسم</label>
                                    <select name="type" id="" class="custom-select">
                                        <option value="0" >قسم رئيسي</option>
                                        <option value="1" <?php echo e($department->type=='1'?'selected':''); ?>>قسم فرعي</option>
                                        <option value="2" <?php echo e($department->type=='2'?'selected':''); ?>>قسم فرعي آخر</option>
                                    </select>
                                </div>
                                <div class="form-group" style="<?php echo e($department->parent_id?'display: block':'display: none'); ?>">
                                    <label for="parent_id">اختر القسم الرئيسي</label>
                                    <select name="parent_id"  class="custom-select">
                                        <option disabled selected>اختر القسم الرئيسي</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ddeparment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ddeparment->id); ?>"<?php echo e($ddeparment->id==$department->parent_id?'selected':''); ?> ><?php echo e($ddeparment->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button class="btn btn-primary" type="submit">تعديل</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row closed -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

            <script>
                $(document).ready(function() { 
                    $('#summernote').summernote({
                    placeholder: 'أدخل وصف القسم',
                    tabsize: 2,
                    height: 200,
                });
                
                    $('select[name="type"]').on('change', function() {
                        var depart = $(this).val();
                        if (depart == '1' || depart == '2' ){
                            $('select[name="parent_id"]').parent().show()
                        }else{
                            $('select[name="parent_id"]').parent().hide()
                        }
                    })
                });
            </script>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indexes\resources\views/departments/edit.blade.php ENDPATH**/ ?>