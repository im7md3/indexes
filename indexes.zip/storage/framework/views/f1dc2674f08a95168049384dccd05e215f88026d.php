<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Document</title>
    <?php echo toastr_css(); ?>
</head>

<body>
    <main>
        <div class="top-header">
            <div class="wrapper">
                <div class="logo">LOGO</div>
                <div class="title-site">
                    <h2>عنوان الموقع</h2>
                    <div class="bars">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="wrapper">
                <div style="max-width: 1000px;margin: auto;padding:20px">
                    <h2> <?php echo e($branch->title); ?></h2>
                        <?php echo $branch->description; ?>

                    
                    <div>
                        <?php if($branch->comments->count()>0): ?>
                        <?php $__currentLoopData = $branch->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="commented d-flex justify-content-between flex-wrap pr-3 mt-4">
                                <div class="d-flex justify-content-between align-items-start">
                                    <img style="width: 50px;border-radius: 50%;height: 50px;"
                                        src="https://sothis.es/wp-content/plugins/all-in-one-seo-pack/images/default-user-image.png"
                                        alt="">
                                    <div class="mr-3">
                                        <div class="client-info mb-1">
                                            <span class="name font-weight-bold"><?php echo e($comment->name); ?></span>
                                        </div>
                                        <div>
                                            <p><?php echo e($comment->content); ?></p>
                                        </div>
                                        <?php if($comment->file): ?>
                                            <img width="300" src="<?php echo e(asset('storage/'.$comment->file)); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div>
                                    <span class="text-muted"> <?php echo e($comment->created_at->diffForHumans()); ?> </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="commented d-flex justify-content-between flex-wrap pr-3 mt-4">
                            لا يوجد أي تعليقات لهذا الفرع
                        </div>
                        <?php endif; ?>

                    </div>
                </div>

                <div class="form">
                    <form action="<?php echo e(route('comments.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="name_project" value="<?php echo e($branch->project->name); ?>">
                        <input type="hidden" name="name_branch" value="<?php echo e($branch->name); ?>">
                        <input type="hidden" name="department_id" value="<?php echo e($branch->id); ?>">
                        <input type="text" name="name" id="" placeholder="أدحل اسمك" required>
                        <textarea name="content" id="" cols="30" rows="10" placeholder="ضع رسالتك" required></textarea>
                        <div>
                            <div class='file file--uploading'>
                                <label for='input-file'>
                                    <i style="margin: 5px;" class="fas fa-paperclip"></i> ارفاق ملف
                                </label>
                                <input id='input-file' type='file' name="comment_file" accept="image/jpeg,image/gif,image/png,application/pdf" />
                            </div>
                        </div>
                        <button style="display: inline-block;max-width: 200px;margin: 0;"
                            type="submit">ارسال</button>

                    </form>
                </div>
            </div>

        </div>
    </main>

    <div class="sidebare">
        <h4><?php echo e($branch->project->name); ?></h4>
        <ul>
            <?php $__currentLoopData = $branch->project->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
            <?php if($department->branches()->count()>0): ?>
            <li><i class="fab fa-plus 1">+</i> <span style="font-weight:bold"><?php echo e($department->name); ?></span></li>
                <?php else: ?>
                <li><a style="color:#00f" href="<?php echo e(route('show.project',['project'=>$branch->project->id,'department'=>$department])); ?>"><?php echo e($department->name); ?></a></li>
            <?php endif; ?>
            <ul class="submenu">
                <?php $__currentLoopData = $department->branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a style="color:#fff" href="<?php echo e(route('show.project',['project'=>$branch->project,'department'=>$branch->department,'branch'=>$branch])); ?>"><?php echo e($branch->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            </li>
        </ul>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\indexes\resources\views\front\projects\project.blade.php ENDPATH**/ ?>