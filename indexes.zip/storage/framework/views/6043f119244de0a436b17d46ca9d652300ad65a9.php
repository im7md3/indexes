
<?php $__env->startSection('css'); ?>

    <?php $__env->startSection('title'); ?>
    إنشاء مشروع جديد
    <?php $__env->stopSection(); ?>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('page-header'); ?>
        <!-- breadcrumb -->
        <?php $__env->startSection('PageTitle'); ?>
        إنشاء مشروع جديد
        <?php $__env->stopSection(); ?>
            <!-- breadcrumb -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('content'); ?>
            <!-- row -->
            <div class="row">
                <div class="col-md-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <ul class=" alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <form action="<?php echo e(Route('projects.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">اسم المشروع</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        placeholder="أدخل اسم المشروع">
                                </div>
                                <div class="form-group">
                                    <label for="notes">ملاحظات على المشروع</label>
                                    <textarea class="form-control" type="text" name="notes" id="notes"
                                        placeholder="يمكنك هنا كتابة ملاحظات عن المشروع"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="password">كلمة سر المشروع</label>
                                    <input class="form-control" type="text" name="password" id="password"
                                        placeholder="أدخل كلمة سر المشروع">
                                </div>
                                <div class="form-group">
                                    <label for="name">حالة المشروع</label>
                                    <select name="status"  class="custom-select">
                                        <option>اختر حالة المشروع</option>
                                        <option value="منجز">منجز</option>
                                        <option value="قيد الإنجاز">قيد الإنجاز</option>
                                        <option value="مغلق">مغلق</option>
                                    </select>
                                </div>
                                <button class="btn btn-primary" type="submit">إنشاء</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row closed -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('js'); ?>

                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indexes\resources\views/projects/create.blade.php ENDPATH**/ ?>