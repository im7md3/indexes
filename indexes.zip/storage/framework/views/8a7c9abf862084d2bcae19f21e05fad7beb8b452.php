<form action="<?php echo e(route('project.confirm',$project)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="password" name="password" id="">
    <button type="submit">تأكيد</button>
</form><?php /**PATH C:\xampp\htdocs\indexes\resources\views/front/projects/password.blade.php ENDPATH**/ ?>