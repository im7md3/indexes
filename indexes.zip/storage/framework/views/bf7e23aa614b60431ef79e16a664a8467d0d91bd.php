
<?php $__env->startSection('css'); ?>
<?php echo toastr_css(); ?>
    <?php $__env->startSection('title'); ?>
    إعدادات الموقع
    <?php $__env->stopSection(); ?>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('page-header'); ?>
        <!-- breadcrumb -->
        <?php $__env->startSection('PageTitle'); ?>
        إعدادات الموقع
        <?php $__env->stopSection(); ?>
            <!-- breadcrumb -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('content'); ?>
            <!-- row -->
            <div class="row">
                <div class="col-md-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <ul class=" alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <form action="<?php echo e(Route('settings.update')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name='id' value="<?php echo e($settings->id); ?>">
                                <div class="form-group">
                                    <label for="name">اسم الموقع</label>
                                    <input class="form-control" type="text" name="site_name" id="site_name" value="<?php echo e($settings->site_name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="image">شعار الموقع</label>
                                    <input type="file" name='image' class="form-control" accept="image/*">
                                </div>
                                
                                <button class="btn btn-primary" type="submit">تعديل</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- row closed -->
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('js'); ?>
            <?php echo toastr_js(); ?>
            <?php echo app('toastr')->render(); ?>
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indexes\resources\views/settings/settings.blade.php ENDPATH**/ ?>