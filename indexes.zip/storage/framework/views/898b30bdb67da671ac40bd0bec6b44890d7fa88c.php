<div class="container-fluid">
    <div class="row">
        <!-- Left Sidebar start-->
        <div class="side-menu-fixed">


            <div class="scrollbar side-menu-bg" style="overflow: scroll">
                <ul class="nav navbar-nav side-menu" id="sidebarnav">
                    <!-- الرئيسية-->
                    <li>
                        <a href="<?php echo e(url('/dashboard')); ?>">
                            <div class="pull-left"><i class="ti-home"></i><span class="right-nav-text">الرئيسية</span>
                            </div>
                            <div class="clearfix"></div>
                        </a>
                    </li>
                    <!-- المشاريع-->
                            <li><a href="<?php echo e(route('projects.index')); ?>">قائمة المشاريع</a></li>
                            <li><a href="<?php echo e(route('projects.create')); ?>">أضف مشروع جديد</a></li>
                            <li><a href="<?php echo e(route('departments.create')); ?>">أضف قسم جديد</a></li>
                            <li><a href="<?php echo e(route('settings.index')); ?>">الإعدادات</a></li>
                    

                </ul>
            </div>

        </div>

        <!-- Left Sidebar End-->

        <!--=================================
<?php /**PATH C:\xampp\htdocs\indexes\resources\views/layouts/main-sidebar.blade.php ENDPATH**/ ?>