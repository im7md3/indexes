<div class="container-fluid">
    <div class="row">
        <!-- Left Sidebar start-->
        <div class="side-menu-fixed">


            <div class="scrollbar side-menu-bg" style="overflow: scroll">
                <ul class="nav navbar-nav side-menu" id="sidebarnav">
                    <!-- الرئيسية-->
                    <li>
                        <a href="{{ url('/dashboard') }}">
                            <div class="pull-left"><i class="ti-home"></i><span class="right-nav-text">الرئيسية</span>
                            </div>
                            <div class="clearfix"></div>
                        </a>
                    </li>
                    <!-- المشاريع-->
                            <li><a href="{{route('projects.index')}}">قائمة المشاريع</a></li>
                            <li><a href="{{route('projects.create')}}">أضف مشروع جديد</a></li>
                            <li><a href="{{route('departments.create')}}">أضف قسم جديد</a></li>
                            <li><a href="{{route('settings.index')}}">الإعدادات</a></li>
                    

                </ul>
            </div>

        </div>

        <!-- Left Sidebar End-->

        <!--=================================
